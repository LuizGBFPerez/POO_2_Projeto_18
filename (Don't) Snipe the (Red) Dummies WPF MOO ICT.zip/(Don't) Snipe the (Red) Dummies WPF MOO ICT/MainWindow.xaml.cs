﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace Sniper_the_Dummies_WPF_MOO_ICT
{
    /*
     * Para este jogo, a alteração feita foi designar um dos dummies que aparece na tela como um civil,
     * para que o jogador perca pontos caso este seja atingido, exigindo que o jogador preste mais atenção
     * no jogo e punindo-o caso contrário.
     * 
     * A primeira mudança ocorre na função DummyMoveTick.
     */
    public partial class MainWindow : Window
    {
        ImageBrush backgroundImage = new ImageBrush();
        ImageBrush ghostSprite = new ImageBrush();

        DispatcherTimer DummyMoveTimer = new DispatcherTimer();
        DispatcherTimer showGhostTimer = new DispatcherTimer();

        int topCount = 0;
        int bottomCount = 0;

        int score;
        int miss;


        List<int> topLocation;
        List<int> bottomLocation;

        List<Rectangle> removeThis = new List<Rectangle>();

        Random rand = new Random();

        public MainWindow()
        {
            InitializeComponent();

            MyCanvas.Focus();

            this.Cursor = Cursors.None;

            backgroundImage.ImageSource = new BitmapImage(new Uri("pack://application:,,,/images/background.png"));
            MyCanvas.Background = backgroundImage;

            scopeImage.Source = new BitmapImage(new Uri("pack://application:,,,/images/sniper-aim.png"));
            scopeImage.IsHitTestVisible = false;

            ghostSprite.ImageSource = new BitmapImage(new Uri("pack://application:,,,/images/ghost.png"));

            DummyMoveTimer.Tick += DummyMoveTick;
            DummyMoveTimer.Interval = TimeSpan.FromMilliseconds(rand.Next(800, 2000));
            DummyMoveTimer.Start();

            showGhostTimer.Tick += GhostAnimation;
            showGhostTimer.Interval = TimeSpan.FromMilliseconds(20);
            showGhostTimer.Start();

            topLocation = new List<int> { 270, 540, 23, 540, 270, 23 };
            bottomLocation = new List<int> { 128, 678, 420, 678, 128, 420 };
        }

        private void GhostAnimation(object sender, EventArgs e)
        {
            scoreText.Content = "Score: " + score;

            missText.Content = "Missed: " + miss;

            foreach (var x in MyCanvas.Children.OfType<Rectangle>())
            {
                if ((string)x.Tag == "ghost")
                {
                    Canvas.SetTop(x, Canvas.GetTop(x) - 5);

                    if (Canvas.GetTop(x) < -180)
                    {
                        removeThis.Add(x);
                    }
                }
            }

            foreach (Rectangle y in removeThis)
            {
                MyCanvas.Children.Remove(y);
            }
        }

        private void DummyMoveTick(object sender, EventArgs e)
        {
            removeThis.Clear();

            foreach (var i in MyCanvas.Children.OfType<Rectangle>())
            {
                /*
                 * Aqui foi adicionado o tag 'civil' - que será introduzido na função ShowDummies - como
                 * condição no if, para que os civis sejam removidos da tela após o tempo certo.
                */
                if ((string)i.Tag == "top" || (string)i.Tag == "bottom" || (string)i.Tag == "civil")
                {
                    removeThis.Add(i);

                    topCount -= 1;
                    bottomCount -= 1;

                    miss += 1;
                }
            }

            if (topCount < 3)
            {
                ShowDummies(topLocation[rand.Next(0, 5)], 35, rand.Next(1, 4), "top");
                topCount += 1;
            }

            if (bottomCount < 3)
            {
                ShowDummies(bottomLocation[rand.Next(0, 5)], 230, rand.Next(1, 4), "bottom");
                bottomCount += 1;
            }
        }

        private void Canvas_MouseMove(object sender, MouseEventArgs e)
        {

            Point position = e.GetPosition(this);

            double pX = position.X;
            double pY = position.Y;


            Canvas.SetLeft(scopeImage, pX - (scopeImage.Width / 2));
            Canvas.SetTop(scopeImage, pY - (scopeImage.Height / 2));
        }

        private void ShowDummies(int x, int y, int skin, string tag)
        {
            ImageBrush dummyBackground = new ImageBrush();

            /* 
             * O código a seguir define o dummy de skin 1 como um 'civil'. Essa designação será usada na
             * função ShootDummy para penalizar o jogador por atirar no dummy vermelho. O resto dos dummies será
             * designado como anteriormente.
             */

            if (skin == 1)
            {
                tag = "civil";
                dummyBackground.ImageSource = new BitmapImage(new Uri("pack://application:,,,/images/dummy01.png"));

            }

            else
            {
                switch (skin)
                {
                    case 2:
                        dummyBackground.ImageSource = new BitmapImage(new Uri("pack://application:,,,/images/dummy02.png"));
                        break;
                    case 3:
                        dummyBackground.ImageSource = new BitmapImage(new Uri("pack://application:,,,/images/dummy03.png"));
                        break;
                    case 4:
                        dummyBackground.ImageSource = new BitmapImage(new Uri("pack://application:,,,/images/dummy04.png"));
                        break;
                }
            }

            Rectangle newRec = new Rectangle
            {
                Tag = tag,
                Width = 80,
                Height = 155,
                Fill = dummyBackground
            };

            Canvas.SetLeft(newRec, x);
            Canvas.SetTop(newRec, y);

            MyCanvas.Children.Add(newRec);
        }

        private void ShootDummy(object sender, MouseButtonEventArgs e)
        {
            if (e.OriginalSource is Rectangle)
            {

                int penalidade = 3; //Introduz um valor pré-definido para penalizar o jogador.

                Rectangle activeRec = (Rectangle)e.OriginalSource;

                /*
                 * O 'if' a seguir foi adicionado para aplicar a punição ao jogador caso o dummy vermelho seja atingido.
                 */
                
                if ((string)activeRec.Tag == "civil")
                {
                    MyCanvas.Children.Remove(activeRec);
                    score -= penalidade;
                }

                /*
                 * A partir daqui, o código continua como anteriormente, apenas com a adição de um 'else' para a função
                 * da pontuação para que esta não se aplique junto à penalização. 
                 */

                else if ((string)activeRec.Tag == "top" || (string)activeRec.Tag == "bottom")
                {
                    MyCanvas.Children.Remove(activeRec);

                    score++;

                    Rectangle ghostRec = new Rectangle
                    {
                        Width = 60,
                        Height = 100,
                        Fill = ghostSprite,
                        Tag = "ghost"
                    };


                    Canvas.SetLeft(ghostRec, Mouse.GetPosition(MyCanvas).X - 40);
                    Canvas.SetTop(ghostRec, Mouse.GetPosition(MyCanvas).Y - 60);

                    MyCanvas.Children.Add(ghostRec);
                }


                if ((string)activeRec.Tag == "top")
                {
                    topCount -= 1;
                }
                if ((string)activeRec.Tag == "bottom")
                {
                    bottomCount -= 1;
                }
            }
        }
    }
}